clear
gcc ./src/master.c -lm -lrt  -o ./bin/master
gcc ./src/ProcessA.c -lbmp -lncurses -lm -lrt -o ./bin/ProcessA
gcc ./src/ProcessB.c -lbmp -lncurses -lm -lrt -o ./bin/ProcessB
./bin/master

