clear
gcc ./src/master.c -lm -lrt  -o ./bin/master
gcc ./src/ProcessANormal.c -lbmp -lncurses -lm -lrt -o ./bin/ProcessANormal
gcc ./src/ProcessAClient.c -lbmp -lncurses -lm -lrt -o ./bin/ProcessAClient
gcc ./src/ProcessAServer.c -lbmp -lncurses -lm -lrt -o ./bin/ProcessAServer
gcc ./src/processB.c -lbmp -lncurses -lm -lrt -o ./bin/processB
./bin/master

