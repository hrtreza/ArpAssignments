#include "./../include/processA_utilities.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <bmpfile.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>

// Size of shared memory object in bytes
const int SIZE = 1600 * 600 * sizeof(int);
bmpfile_t *bitmap;
rgb_pixel_t pixel = {0, 0, 100, 0};
// Shared memory object name
const char *name = "shm";
// File descriptor of shared memory
int fd;
// Shared memory object pointer
int *ptr;
// A flag to save only if this is true
bool flag_to_save = false;
// Variables to create bitmap, so we initialize here to avoid repeating inside the function
int width = 1600;
int height = 600;
int depth = 4;

// Function to update shared memory each time the object is moved
void update_shared_memory(bmpfile_t *bitmap)
{
    for (int i = 0; i < 1600; i++)
    {
        for (int j = 0; j < 600; j++)
        {
            rgb_pixel_t *pixel = bmp_get_pixel(bitmap, i, j);
            ptr[i * 599 + j] = pixel->red;
        }
    }
}

// Function to create bitmap and save the bitmap if p is pressed
void bitmap_create(int i_circle, int j_circle)
{
    bitmap = bmp_create(width, height, depth);
    int radius = 20;

    for (int i = -radius; i <= radius; i++)
    {
        for (int j = -radius; j <= radius; j++)
        {
            // Checking if the point is within the circle
            if (sqrt(pow(i, 2) + pow(j, 2)) < radius)
            {
                // Color circle
                bmp_set_pixel(bitmap, (i_circle) * (width / (COLS - BTN_SIZE_X - 2)) + i, (j_circle) * (height / LINES) + j, pixel);
            }
        }
    }

    if (flag_to_save)
    {
        // Save the bitmap file with the name of "printed"
        bmp_save(bitmap, "out/printed");
        // Set the flag to false so that next time it is called does not change the saved bitmap
        flag_to_save = false;
    }
}

int main(int argc, char *argv[])
{
    fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    // Configure the size of the shared memory object
    ftruncate(fd, SIZE);
    // Memory map shared memory object
    ptr = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, fd, 0);

    // Utility variable to avoid triggering resize event on launch
    int first_resize = TRUE;

    // Initialize UI
    init_console_ui();
    bitmap_create(circle.x, circle.y);
    // Update shared memory
    update_shared_memory(bitmap);

    // Infinite loop
    while (TRUE)
    {
        // input in non-blocking mode
        int cmd = getch();

        switch (cmd)
        {
            case KEY_RESIZE:
            {
                if (first_resize)
                {
                    first_resize = FALSE;
                }
                else
                {
                    reset_console_ui();
                }
                break;
            }
            case KEY_MOUSE:
            {
                if (getmouse(&event) == OK)
                {
                    if (check_button_pressed(print_btn, &event))
                    {
                        // Put flag to true to save bitmap
                        flag_to_save = true;
                        // Create bitmap and update shared memory
                        bitmap_create(circle.x, circle.y);
                        // Update shared memory
                        update_shared_memory(bitmap);
                        mvprintw(LINES - 1, 1, "Print button pressed");
                        refresh();
                        sleep(1);
                        for (int j = 0; j < COLS - BTN_SIZE_X - 2; j++)
                        {
                            mvaddch(LINES - 1, j, ' ');
                        }
                    }
                }
                break;
            }
            case KEY_LEFT:
            case KEY_RIGHT:
            case KEY_UP:
            case KEY_DOWN:
            {
                move_circle(cmd);
                draw_circle();
                // Create bitmap and update shared memory
                bitmap_create(circle.x, circle.y);
                // Update shared memory
                update_shared_memory(bitmap);
                break;
            }
        }
    }

    endwin();
    return 0;
}

