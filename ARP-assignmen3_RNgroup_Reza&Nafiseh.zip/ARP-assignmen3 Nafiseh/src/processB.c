#include "./../include/processB_utilities.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <bmpfile.h>
#include <fcntl.h>
#include <sys/mman.h>

const int SIZE = 1600 * 600 * sizeof(int);
bmpfile_t *bmap;
// Shared memory object
const char *name = "shm";
// File descriptor
int fd;
// Shared memory object pointer
int *ptr;
int i_center;
int j_center;

// Function to find the center of the red pixels
void find_center()
{
    int i_min = 1600;
    int i_max = 0;
    int j_min = 600;
    int j_max = 0;

    for (int i = 0; i < 1600; i++)
    {
        for (int j = 0; j < 600; j++)
        {
            rgb_pixel_t *pixel = bmp_get_pixel(bmap, i, j);

            if (pixel->red == 100)
            {
                if (i < i_min)
                    i_min = i;
                if (i > i_max)
                    i_max = i;
                if (j < j_min)
                    j_min = j;
                if (j > j_max)
                    j_max = j;
            }
        }
    }

    i_center = (i_min + i_max) / 2;
    j_center = (j_min + j_max) / 2;
    i_center /= (1600 / COLS);
    j_center /= (600 / LINES);

    mvprintw(LINES - 1, 1, "loc of i is : %d", i_center);
    mvprintw(LINES - 2, 1, "loc of j is : %d", j_center);
    mvaddch(j_center, i_center, '0');
    refresh();
}

// Function to load shared memory and create bitmap
void load_shared_memory()
{
    bmap = bmp_create(1600, 600, 4);

    for (int i = 0; i < 1600; i++)
    {
        for (int j = 0; j < 600; j++)
        {
            if (ptr[i * 599 + j] == 100)
            {
                rgb_pixel_t pixel = {0, 0, ptr[i * 599 + j], 0};
                bmp_set_pixel(bmap, i, j, pixel);
            }
            else
            {
                rgb_pixel_t pixel = {255, 255, 255, 0};
                bmp_set_pixel(bmap, i, j, pixel);
            }
        }
    }
}

int main(int argc, char const *argv[])
{
    // Open shared memory as ReadOnly
    fd = shm_open(name, O_RDONLY, 0666);
    // Memory map the shared memory object
    ptr = mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);
    // Utility variable to avoid trigger resize event on launch
    int first_resize = TRUE;
    // Initialize UI
    init_console_ui();
    // Infinite loop
    while (TRUE)
    {
        // Get input in non-blocking mode
        int cmd = getch();
        // Switch statement to handle different commands
        switch (cmd)
        {
            case KEY_RESIZE:
            {
                // If user resizes screen, re-draw UI...
                if (first_resize)
                {
                    first_resize = FALSE;
                }
                else
                {
                    reset_console_ui();
                }
                break;
            }
            default:
            {
                // Load shared memory and find center
                load_shared_memory();
                find_center();
                // Destroy bitmap
                bmp_destroy(bmap);
                break;
            }
        }
    }
    endwin();
    return 0;
}

