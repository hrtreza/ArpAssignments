#include "./../include/processA_utilities.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <bmpfile.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

// Size of shared memory object in bytes
const int SIZE = 1600 * 600 * sizeof(int);
bmpfile_t *bitmap;
rgb_pixel_t pixel = {0, 0, 100, 0};
const char *name = "sharedmem";
int fd;
int *ptr;
bool flag_to_save = false;
int width = 1600;
int height = 600;
int depth = 4;

// Function to update shared memory with pixel values from the bitmap
void update_shared_memory(bmpfile_t *bitmap)
{
    for (int i = 0; i < 1600; i++)
    {
        for (int j = 0; j < 600; j++)
        {
            rgb_pixel_t *pixel = bmp_get_pixel(bitmap, i, j);
            ptr[i * 599 + j] = pixel->red;
        }
    }
}

// Function to create a bitmap and save it if flag_to_save is true
void bitmap_create(int i_circle, int j_circle)
{
    bitmap = bmp_create(width, height, depth);
    int radius = 20;

    for (int i = -radius; i <= radius; i++)
    {
        for (int j = -radius; j <= radius; j++)
        {
            if (sqrt(pow(i, 2) + pow(j, 2)) < radius)
            {
                // Color the circle within the radius
                bmp_set_pixel(bitmap, (i_circle) * (width / (COLS - BTN_SIZE_X - 2)) + i, (j_circle) * (height / LINES) + j, pixel);
            }
        }
    }

    if (flag_to_save)
    {
        // Save the bitmap file
        bmp_save(bitmap, "out/printed");
        // Set the flag to false to avoid saving it again
        flag_to_save = false;
    }
}

int main(int argc, char *argv[])
{
    char *ip;
    int sockfd, port_numb, n;
    ip = strtok(argv[1], " ");
    port_numb = atoi(strtok(NULL, " "));

    struct sockaddr_in serv_addr;
    struct hostent *server;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        perror("socket");

    server = gethostbyname(ip);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(port_numb);

    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
        perror("connect");

    fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    ftruncate(fd, SIZE);
    ptr = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, fd, 0);

    int first_resize = TRUE;
    char inpt[80];
    init_console_ui();
    bitmap_create(circle.x, circle.y);
    update_shared_memory(bitmap);

    while (TRUE)
    {
        int cmd = getch();

        switch (cmd)
        {
            case KEY_RESIZE:
            {
                if (first_resize)
                {
                    first_resize = FALSE;
                }
                else
                {
                    reset_console_ui();
                }
                break;
            }
            case KEY_MOUSE:
            {
                if (getmouse(&event) == OK)
                {
                    if (check_button_pressed(print_btn, &event))
                    {
                        flag_to_save = true;
                        bitmap_create(circle.x, circle.y);
                        update_shared_memory(bitmap);
                        bzero(inpt, 80);
                        strcpy(inpt, "p");
                        n = write(sockfd, inpt, strlen(inpt));
                        if (n < 0)
                            perror("write");
                        mvprintw(LINES - 1, 1, "Print button pressed");
                        refresh();
                        sleep(1);
                        for (int j = 0; j < COLS - BTN_SIZE_X - 2; j++)
                        {
                            mvaddch(LINES - 1, j, ' ');
                        }
                    }
                }
                break;
            }
            case KEY_LEFT:
            case KEY_RIGHT:
            case KEY_UP:
            case KEY_DOWN:
            {
                bzero(inpt, 80);
                sprintf(inpt, "%d", cmd);
                n = write(sockfd, inpt, strlen(inpt));
                if (n < 0)
                    perror("write");

                move_circle(cmd);
                draw_circle();
                bitmap_create(circle.x, circle.y);
                update_shared_memory(bitmap);
                break;
            }
        }
    }

    endwin();
    return 0;
}

