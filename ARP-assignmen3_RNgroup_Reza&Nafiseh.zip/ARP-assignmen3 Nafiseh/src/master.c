#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

char  p1[50]="./bin/ProcessAServer";
char  p2[50]="./bin/ProcessAClient";
char  p3[50]="./bin/ProcessANormal";
pid_t pid_procA;
pid_t pid_procB;

int spawn(const char * program, char * arg_list[]) {
  pid_t child_pid = fork();
  if(child_pid < 0) {
    perror("Error while forking...");
    return 1;
  }
  else if(child_pid != 0) {
    return child_pid;
  }
  else {
    if(execvp (program, arg_list) == 0);
    perror("Exec failed");
    return 1;
  }
}

void signal_handler(int numb){
    if (numb == SIGINT){
        printf("SIGINT Signal Received!\n");
        kill(pid_procA, SIGKILL);
        kill(pid_procB, SIGKILL);
    }
}

int main() {
  signal(SIGINT, signal_handler);
  char portnumber[10],ip[20],sendparam[30];
  printf("####################################\n");
  printf("\n     Group Members\n     Nafiseh Monavari S5174160\n     Reza Taleshi S5029729\n\n");
  printf("####################################\n");
  printf("choose which mode to run\n");
  printf("1. Normal Mode.\n2. Server Mode.\n3. Client Mode.\nPress any key to Exit.\n");  
  int ch;
  scanf("%d",&ch);
  if(ch==1){
      strcpy(p1,p3);
  }else if(ch==2){
      printf("Server mode started!!!\n");
      printf("Enter port number:\n");
      scanf("%s",portnumber);
      strcpy(sendparam,portnumber);
  }else if(ch==3){
      printf("Client mode started!!!\n");
      printf("Enter port number:\n");
      scanf("%s",portnumber);
      printf("Enter IP address to connect:\n");
      scanf("%s",ip);
      strcpy(sendparam,ip);
      strcat(sendparam," ");
      strcat(sendparam,portnumber);
      strcpy(p1,p2);
  }else{
      return 0;
  }
  char * arg_list_A[] = {"/usr/bin/konsole", "-e", p1, sendparam };
  char *  arg_list_B[] = { "/usr/bin/konsole", "-e", "./bin/processB", NULL };
  pid_procA = spawn("/usr/bin/konsole", arg_list_A);
  pid_procB = spawn("/usr/bin/konsole", arg_list_B);
  int status;
  pid_t pid=wait(&status);
  if(pid==pid_procA){
      kill(pid_procB, SIGTERM);
  }else if(pid==pid_procB){
      kill(pid_procA, SIGTERM);
  }
  printf ("Main program exiting with status %d\n", status);  
  return 0;
}

