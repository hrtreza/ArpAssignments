#include "./../include/inspection_utilities.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <signal.h>
#include <time.h>

#define v_mx_fifo "/tmp/v_mx_fifo"
#define v_mz_fifo "/tmp/v_mz_fifo"
#define p_mx_fifo "/tmp/p_mx_fifo"
#define p_mz_fifo "/tmp/p_mz_fifo"
#define watchdog_p_mx_fifo "/tmp/watchdog_p_mx_fifo"
#define watchdog_p_mz_fifo "/tmp/watchdog_p_mz_fifo"

FILE *log_file;

char time_buff[20];
struct tm *sTm;
time_t t;

// Function to get current timestamp
void timestamp() {
    t = time(NULL);
    sTm = gmtime(&t);
    strftime(time_buff, sizeof(time_buff), "%Y-%m-%d %H:%M:%S", sTm);
}

float p_mx = 0.0;
float p_mz = 0.0;

char p_mx_fifo_payload[100];
char p_mz_fifo_payload[100];
int p_mx_fd, p_mz_fd, maxfd;
int r_status, w_status;

// Signal handler for termination
void Terminate(int signal) {
    printf("Terminating\n");
    // Log termination
    timestamp();
    fprintf(log_file, "%s Terminating\n", time_buff);
    fflush(log_file);
    // Close file descriptors and clean up
    close(p_mx_fd);
    close(p_mz_fd);
    fclose(log_file);
    // Terminate
    exit(EXIT_SUCCESS);
}

// Signal handler for SIGINT and SIGTERM
void sig_handler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        Terminate(signal);
    }
}

// Function to retrieve process ID
long process_id(const char* process_name) {
    char line[10];
    FILE* pid_file = popen(process_name, "r");
    fgets(line, sizeof(line), pid_file);
    return strtol(line, NULL, 10);
}

int main(int argc, char const *argv[]) {
    // Get process IDs to send signals
    long pid_cmd = process_id("pidof -s command");
    long pid_motorx = process_id("pidof -s motorx");
    long pid_motorz = process_id("pidof -s motorz");

    // Initialize log file
    log_file = fopen("log/inspection_console.log", "w");
    if (log_file == NULL) {
        perror("Error while opening the log file");
        return 1;
    }
    // Log start
    timestamp();
    fprintf(log_file, "%s log started\n", time_buff);
    fflush(log_file);

    // Open p_mx_fifo for reading
    p_mx_fd = open(p_mx_fifo, O_RDONLY | O_NONBLOCK);
    if (p_mx_fd == -1) {
        perror("Error while opening p_mx_fifo");
        timestamp();
        fprintf(log_file, "%s Error while opening p_mx_fifo\n", time_buff);
        fflush(log_file);
    }

    // Open p_mz_fifo for reading
    p_mz_fd = open(p_mz_fifo, O_RDONLY | O_NONBLOCK);
    if (p_mz_fd == -1) {
        perror("Error while opening p_mz_fifo");
        timestamp();
        fprintf(log_file, "%s Error while opening p_mz_fifo\n", time_buff);
        fflush(log_file);
    }

    // Register signal handlers
    if (signal(SIGINT, sig_handler) == SIG_ERR || signal(SIGTERM, sig_handler) == SIG_ERR) {
        perror("Error while registering Terminate signal handler");
        timestamp();
        fprintf(log_file, "%s Error while registering Terminate signal handler\n", time_buff);
        fflush(log_file);
    }

    maxfd = (p_mx_fd > p_mz_fd) ? p_mx_fd : p_mz_fd;

    int first_resize = TRUE; // Utility variable to avoid triggering resize event on launch

    float ee_x, ee_y; // End-effector coordinates

    // Initialize User Interface
    init_console_ui();

    // Infinite loop
    while (TRUE) {
        fd_set readfds;
        FD_ZERO(&readfds);

        FD_SET(p_mx_fd, &readfds);
        FD_SET(p_mz_fd, &readfds);

        // Wait for data on p_mx_fifo or p_mz_fifo
        select(maxfd + 1, &readfds, NULL, NULL, NULL);

        switch (FD_ISSET(p_mx_fd, &readfds)) {
            case TRUE:
                r_status = read(p_mx_fd, p_mx_fifo_payload, 100);
                if (r_status > 0) {
                    p_mx = atof(p_mx_fifo_payload);
                    // Log p_mx value
                    timestamp();
                    fprintf(log_file, "%s p_mx: %f\n", time_buff, p_mx);
                    fflush(log_file);
                }
                break;
            default:
                break;
        }

        switch (FD_ISSET(p_mz_fd, &readfds)) {
            case TRUE:
                r_status = read(p_mz_fd, p_mz_fifo_payload, 100);
                if (r_status > 0) {
                    p_mz = atof(p_mz_fifo_payload);
                    // Log p_mz value
                    timestamp();
                    fprintf(log_file, "%s p_mz: %f\n", time_buff, p_mz);
                    fflush(log_file);
                }
                break;
            default:
                break;
        }

        // Get mouse/resize commands in non-blocking mode
        int cmd = getch();

        switch (cmd) {
            case KEY_RESIZE:
                if (!first_resize) {
                    reset_console_ui();
                }
                first_resize = FALSE;
                break;
            case KEY_MOUSE: {
                MEVENT event;
                if (getmouse(&event) == OK) {
                    if (check_button_pressed(stp_button, &event)) {
                        mvprintw(LINES - 1, 1, "Emergency STP button pressed");
                        refresh();
                        sleep(1);
                        for (int j = 0; j < COLS; j++) {
                            mvaddch(LINES - 1, j, ' ');
                        }
                        // Log STOP button press
                        timestamp();
                        fprintf(log_file, "%s Emergency STP button pressed\n", time_buff);
                        fflush(log_file);

                        // Sending SIGUSR1/Stop Signal to command/motorx/motorz processes
                        kill(pid_cmd, SIGUSR1);
                        kill(pid_motorx, SIGUSR1);
                        kill(pid_motorz, SIGUSR1);
                    } else if (check_button_pressed(rst_button, &event)) {
                        mvprintw(LINES - 1, 1, "Emergency RST button pressed");
                        refresh();
                        sleep(1);
                        for (int j = 0; j < COLS; j++) {
                            mvaddch(LINES - 1, j, ' ');
                        }
                        // Log RESET button press
                        timestamp();
                        fprintf(log_file, "%s Emergency RST button pressed\n", time_buff);
                        fflush(log_file);

                        // Sending SIGUSR2/Reset Signal to command/motorx/motorz processes
                        kill(pid_cmd, SIGUSR2);
                        kill(pid_motorx, SIGUSR2);
                        kill(pid_motorz, SIGUSR2);
                    }
                }
                break;
            }
            default:
                break;
        }

        ee_x = p_mx;
        ee_y = p_mz;

        // Update UI
        update_console_ui(&ee_x, &ee_y);
    }

    // Close FIFOs and log file
    close(p_mx_fd);
    close(p_mz_fd);
    fclose(log_file);

    // Terminate
    endwin();
    return 0;
}

