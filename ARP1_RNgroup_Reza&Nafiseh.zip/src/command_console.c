#include "./../include/command_utilities.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <time.h>

#define v_mx_fifo "/tmp/v_mx_fifo"
#define v_mz_fifo "/tmp/v_mz_fifo"
#define p_mx_fifo "/tmp/p_mx_fifo"
#define p_mz_fifo "/tmp/p_mz_fifo"
#define watchdog_p_mx_fifo "/tmp/watchdog_p_mx_fifo"
#define watchdog_p_mz_fifo "/tmp/watchdog_p_mz_fifo"

#define v_speed 1
#define v_limit 4

FILE *log_file;

char time_buff[20];
struct tm *sTm;
time_t t;

void timestamp() {
  t = time(NULL);
  sTm = gmtime(&t);
  strftime(time_buff, sizeof(time_buff), "%Y-%m-%d %H:%M:%S", sTm);
}

float v_mx = 0.0;
float v_mz = 0.0;

char v_mx_fifo_payload[100];
char v_mz_fifo_payload[100];
int v_mx_fd, v_mz_fd;
int r_status, w_status;

void STP_sig_handler(int signal) {
  v_mx = 0.0;
  v_mz = 0.0;
  // Log
  timestamp();
  fprintf(log_file, "%s Emergency Stop\n", time_buff);
  fprintf(log_file, "%s v_mx = %f\n", time_buff, v_mx);
  fprintf(log_file, "%s v_mz = %f\n", time_buff, v_mz);
  fflush(log_file);
}

void RST_sig_handler(int signal) {
  v_mx = 0.0;
  v_mz = 0.0;
  // Log
  timestamp();
  fprintf(log_file, "%s Emergency Reset\n", time_buff);
  fprintf(log_file, "%s v_mx = %f\n", time_buff, v_mx);
  fprintf(log_file, "%s v_mz = %f\n", time_buff, v_mz);
  fflush(log_file);
}

void Terminate(int signal) {
  printf("Terminating\n");
  // Log
  timestamp();
  fprintf(log_file, "%s Terminating\n", time_buff);
  fflush(log_file);
  // Close FIFOs
  close(v_mx_fd);
  close(v_mz_fd);
  // Log
  timestamp();
  fprintf(log_file, "%s log closed\n", time_buff);
  fflush(log_file);

  fclose(log_file);

  // Terminate
  exit(EXIT_SUCCESS);
}

void sig_handler(int signal) {
  if (signal == SIGUSR1) {
    STP_sig_handler(signal);
  } else if (signal == SIGUSR2) {
    RST_sig_handler(signal);
  } else if (signal == SIGINT) {
    Terminate(signal);
  } else if (signal == SIGTERM) {
    Terminate(signal);
  }
}

int main(int argc, char const *argv[]) {
    //******** log init ********//
    log_file = fopen("log/command_console.log", "w");
    if (log_file == NULL) {
        perror("Error while opening the log file");
        return 1;
    }
    //******** log ********//
    timestamp();
    fprintf(log_file, "%s log started\n", time_buff);
    fflush(log_file);

    //******** fifo init ********//
    // Open v_mx_fifo
    v_mx_fd = open(v_mx_fifo, O_WRONLY);
    if (v_mx_fd == -1) {
        perror("Error while opening v_mx_fifo");
        //******** log ********//
        timestamp();
        fprintf(log_file, "%s Error while opening v_mx_fifo\n", time_buff);
        fflush(log_file);
    }
    // Open v_mz_fifo
    v_mz_fd = open(v_mz_fifo, O_WRONLY);
    if (v_mz_fd == -1) {
        perror("Error while opening v_mz_fifo");
        //******** log ********//
        timestamp();
        fprintf(log_file, "%s Error while opening v_mz_fifo\n", time_buff);
        fflush(log_file);
    }

    if (signal(SIGUSR1, sig_handler) == SIG_ERR) {
        perror("Error while getting stop signal");
        //******** log ********//
        timestamp();
        fprintf(log_file, "%s Error while getting stop signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGUSR2, sig_handler) == SIG_ERR) {
        perror("Error while getting reset signal");
        //******** log ********//
        timestamp();
        fprintf(log_file, "%s Error while getting reset signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGINT, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        //******** log ********//
        timestamp();
        fprintf(log_file, "%s Error while getting Terminate signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGTERM, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        //******** log ********//
        timestamp();
        fprintf(log_file, "%s Error while getting Terminate signal\n", time_buff);
        fflush(log_file);
    }
    // Utility variable to avoid triggering resize event on launch
    int first_resize = TRUE;

    // Initialize User Interface
    init_console_ui();

    // Infinite loop
    while (TRUE) {
        // Get mouse/resize commands in non-blocking mode...
        int cmd = getch();

        // If user resizes screen, re-draw UI
        if (cmd == KEY_RESIZE) {
            if (first_resize) {
                first_resize = FALSE;
            } else {
                reset_console_ui();
            }
        }
        // Else if mouse has been pressed
        else if (cmd == KEY_MOUSE) {
            // Check which button has been pressed...
            if (getmouse(&event) == OK) {
                // Vx-- button pressed
                if (check_button_pressed(vx_decr_btn, &event)) {
                    mvprintw(LINES - 1, 1, "Horizontal Speed Decreased");
                    refresh();
                    sleep(1);
                    for (int j = 0; j < COLS; j++) {
                        mvaddch(LINES - 1, j, ' ');
                    }
                    // Decrease v_mx
                    v_mx -= v_speed;
                    if (v_mx < -v_limit) {
                        v_mx = -v_limit;
                    }
                    // Write to v_mx_fifo
                    sprintf(v_mx_fifo_payload, "%f", v_mx);
                    w_status = write(v_mx_fd, v_mx_fifo_payload, strlen(v_mx_fifo_payload));
                    if (w_status == -1) {
                        perror("Error while writing to v_mx_fifo");
                        //******** log ********//
                        timestamp();
                        fprintf(log_file, "%s Error while writing to v_mx_fifo\n", time_buff);
                        fflush(log_file);
                    }
                    //******** log ********//
                    timestamp();
                    fprintf(log_file, "%s Horizontal Speed Decreased\n", time_buff);
                    fprintf(log_file, "%s v_mx = %f\n", time_buff, v_mx);
                    fflush(log_file);
                }
                // Vx++ button pressed
                else if (check_button_pressed(vx_incr_btn, &event)) {
                    mvprintw(LINES - 1, 1, "Horizontal Speed Increased");
                    refresh();
                    sleep(1);
                    for (int j = 0; j < COLS; j++) {
                        mvaddch(LINES - 1, j, ' ');
                    }
                    // Increase v_mx
                    v_mx += v_speed;
                    if (v_mx > v_limit) {
                        v_mx = v_limit;
                    }
                    // Write to v_mx_fifo
                    sprintf(v_mx_fifo_payload, "%f", v_mx);
                    w_status = write(v_mx_fd, v_mx_fifo_payload, strlen(v_mx_fifo_payload));
                    if (w_status == -1) {
                        perror("Error while writing to v_mx_fifo");
                        //******** log ********//
                        timestamp();
                        fprintf(log_file, "%s Error while writing to v_mx_fifo\n", time_buff);
                        fflush(log_file);
                    }
                    //******** log ********//
                    timestamp();
                    fprintf(log_file, "%s Horizontal Speed Increased\n", time_buff);
                    fprintf(log_file, "%s v_mx = %f\n", time_buff, v_mx);
                    fflush(log_file);
                }
                // Vx stop button pressed
                else if (check_button_pressed(vx_stp_button, &event)) {
                    mvprintw(LINES - 1, 1, "Horizontal Motor Stopped");
                    refresh();
                    sleep(1);
                    for (int j = 0; j < COLS; j++) {
                        mvaddch(LINES - 1, j, ' ');
                    }
                    // Set v_mx to 0 in order to stop the motor
                    v_mx = 0.0;
                    // Write to v_mx_fifo
                    sprintf(v_mx_fifo_payload, "%f", v_mx);
                    w_status = write(v_mx_fd, v_mx_fifo_payload, strlen(v_mx_fifo_payload));
                    if (w_status == -1) {
                        perror("Error while writing to v_mx_fifo");
                        //******** log ********//
                        timestamp();
                        fprintf(log_file, "%s Error while writing to v_mx_fifo\n", time_buff);
                        fflush(log_file);
                    }
                    //******** log ********//
                    timestamp();
                    fprintf(log_file, "%s Horizontal Motor Stopped\n", time_buff);
                    fprintf(log_file, "%s v_mx = %f\n", time_buff, v_mx);
                    fflush(log_file);
                }
                // Vz-- button pressed
                else if (check_button_pressed(vz_decr_btn, &event)) {
                    mvprintw(LINES - 1, 1, "Vertical Speed Decreased");
                    refresh();
                    sleep(1);
                    for (int j = 0; j < COLS; j++) {
                        mvaddch(LINES - 1, j, ' ');
                    }
                    // Decrease v_mz
                    v_mz -= v_speed;
                    if (v_mz < -v_limit) {
                        v_mz = -v_limit;
                    }
                    // Write to v_mz_fifo
                    sprintf(v_mz_fifo_payload, "%f", v_mz);
                    w_status = write(v_mz_fd, v_mz_fifo_payload, strlen(v_mz_fifo_payload));
                    if (w_status == -1) {
                        perror("Error while writing to v_mz_fifo");
                        //******** log ********//
                        timestamp();
                        fprintf(log_file, "%s Error while writing to v_mz_fifo\n", time_buff);
                        fflush(log_file);
                    }
                    //******** log ********//
                    timestamp();
                    fprintf(log_file, "%s Vertical Speed Decreased\n", time_buff);
                    fprintf(log_file, "%s v_mz = %f\n", time_buff, v_mz);
                    fflush(log_file);
                }
                // Vz++ button pressed
                else if (check_button_pressed(vz_incr_btn, &event)) {
                    mvprintw(LINES - 1, 1, "Vertical Speed Increased");
                    refresh();
                    sleep(1);
                    for (int j = 0; j < COLS; j++) {
                        mvaddch(LINES - 1, j, ' ');
                    }
                    // Increase v_mz
                    v_mz += v_speed;
                    if (v_mz > v_limit) {
                        v_mz = v_limit;
                    }
                    // Write to v_mz_fifo
                    sprintf(v_mz_fifo_payload, "%f", v_mz);
                    w_status = write(v_mz_fd, v_mz_fifo_payload, strlen(v_mz_fifo_payload));
                    if (w_status == -1) {
                        perror("Error while writing to v_mz_fifo");
                        //******** log ********//
                        timestamp();
                        fprintf(log_file, "%s Error while writing to v_mz_fifo\n", time_buff);
                        fflush(log_file);
                    }
                    //******** log ********//
                    timestamp();
                    fprintf(log_file, "%s Vertical Speed Increased\n", time_buff);
                    fprintf(log_file, "%s v_mz = %f\n", time_buff, v_mz);
                    fflush(log_file);
                }
                // Vz stop button pressed
                else if (check_button_pressed(vz_stp_button, &event)) {
                    mvprintw(LINES - 1, 1, "Vertical Motor Stopped");
                    refresh();
                    sleep(1);
                    for (int j = 0; j < COLS; j++) {
                        mvaddch(LINES - 1, j, ' ');
                    }
                    // Set v_mz to 0 in order to stop the motor
                    v_mz = 0.0;
                    // Write to v_mz_fifo
                    sprintf(v_mz_fifo_payload, "%f", v_mz);
                    w_status = write(v_mz_fd, v_mz_fifo_payload, strlen(v_mz_fifo_payload));
                    if (w_status == -1) {
                        perror("Error while writing to v_mz_fifo");
                        //******** log ********//
                        timestamp();
                        fprintf(log_file, "%s Error while writing to v_mz_fifo\n", time_buff);
                        fflush(log_file);
                    }
                    //******** log ********//
                    timestamp();
                    fprintf(log_file, "%s Vertical Motor Stopped\n", time_buff);
                    fprintf(log_file, "%s v_mz = %f\n", time_buff, v_mz);
                    fflush(log_file);
                }
            }
        }
        refresh();
    }
    //******** fifo close ********//
    close(v_mx_fd);
    close(v_mz_fd);
    fclose(log_file);
    return 0;
}

