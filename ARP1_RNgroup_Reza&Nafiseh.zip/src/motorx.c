#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>

#define FIFO_PATH_MAX 100

char v_mx_fifo[] = "/tmp/v_mx_fifo";
char p_mx_fifo[] = "/tmp/p_mx_fifo";
char watchdog_p_mx_fifo[] = "/tmp/watchdog_p_mx_fifo";
char log_file_path[] = "log/motorx.log";

FILE *log_file;

char time_buff[20];
struct tm *sTm;
time_t t;

// Function to generate a timestamp
void timestamp() {
    t = time(NULL);
    sTm = gmtime(&t);
    strftime(time_buff, sizeof(time_buff), "%Y-%m-%d %H:%M:%S", sTm);
}

float v_mx = 0.0;
float p_mx = 0.0;
float p_mx_old = 0.0;
int update = 0;
int reset = 0;
char v_mx_fifo_payload[FIFO_PATH_MAX];
char p_mx_fifo_payload[FIFO_PATH_MAX];
int v_mx_fd, p_mx_fd, watchdog_p_mx_fd;
int r_status, w_status;

// Signal handler for stop signal
void STP_sig_handler(int signal) {
    v_mx = 0.0;
    reset = 0;
    timestamp();
    fprintf(log_file, "%s Emergency Motorx Stopped\n", time_buff);
    fprintf(log_file, "%s v_mx = %f\n", time_buff, v_mx);
    fflush(log_file);
}

// Signal handler for reset signal
void RST_sig_handler(int signal) {
    v_mx = -1.0;
    reset = 1;
}

// Signal handler for termination signal
void Terminate(int signal) {
    printf("Terminating\n");
    timestamp();
    fprintf(log_file, "%s Terminating\n", time_buff);
    fflush(log_file);
    close(v_mx_fd);
    close(p_mx_fd);
    close(watchdog_p_mx_fd);
    timestamp();
    fprintf(log_file, "%s log closed\n", time_buff);
    fflush(log_file);
    fclose(log_file);
    exit(EXIT_SUCCESS);
}

// Signal handler for various signals
void sig_handler(int signal) {
    switch (signal) {
        case SIGUSR1:
            STP_sig_handler(signal);
            break;
        case SIGUSR2:
            RST_sig_handler(signal);
            break;
        case SIGINT:
            Terminate(signal);
            break;
        case SIGTERM:
            Terminate(signal);
            break;
        default:
            break;
    }
}

// Function to open a FIFO
void open_fifo(const char *fifo_path, int mode, int *fd, const char *error_message) {
    *fd = open(fifo_path, mode);
    if (*fd == -1) {
        perror(error_message);
        timestamp();
        fprintf(log_file, "%s %s\n", time_buff, error_message);
        fflush(log_file);
    }
}

// Function to write data to a FIFO
void write_to_fifo(int fd, const char *fifo_payload, const char *error_message) {
    w_status = write(fd, fifo_payload, strlen(fifo_payload));
    if (w_status == -1) {
        perror(error_message);
        timestamp();
        fprintf(log_file, "%s %s\n", time_buff, error_message);
        fflush(log_file);
    }
}

int main(int argc, char *argv[]) {
    // Open log file
    log_file = fopen(log_file_path, "w");
    if (log_file == NULL) {
        perror("Error while opening the log file");
        return 1;
    }
    timestamp();
    fprintf(log_file, "%s log started\n", time_buff);
    fflush(log_file);

    // Open FIFOs
    open_fifo(v_mx_fifo, O_RDONLY | O_NONBLOCK, &v_mx_fd, "Error while opening v_mx_fifo");
    open_fifo(p_mx_fifo, O_WRONLY, &p_mx_fd, "Error while opening p_mx_fifo");
    open_fifo(watchdog_p_mx_fifo, O_WRONLY, &watchdog_p_mx_fd, "Error while opening watchdog_p_mx_fifo");

    srand(time(NULL));
    double max_error_percentage = 0.05;
    double error = 0.0;

    // Set up signal handlers
    if (signal(SIGUSR1, sig_handler) == SIG_ERR) {
        perror("Error while getting stop signal");
        timestamp();
        fprintf(log_file, "%s Error while getting stop signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGUSR2, sig_handler) == SIG_ERR) {
        perror("Error while getting reset signal");
        timestamp();
        fprintf(log_file, "%s Error while getting reset signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGINT, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        timestamp();
        fprintf(log_file, "%s Error while getting Terminate signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGTERM, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        timestamp();
        fprintf(log_file, "%s Error while getting Terminate signal\n", time_buff);
        fflush(log_file);
    }

    while (1) {
        switch (reset) {
            case 1:
                if (p_mx_old == 0) {
                    v_mx = 0.0;
                    reset = 0;
                } else {
                    v_mx = -1.0;
                    update = 1;
                }
                timestamp();
                fprintf(log_file, "%s v_mx in reset mode: %f\n", time_buff, v_mx);
                fflush(log_file);
                break;
            default:
                r_status = read(v_mx_fd, v_mx_fifo_payload, FIFO_PATH_MAX);
                if (r_status > 0) {
                    v_mx = atof(v_mx_fifo_payload);
                    timestamp();
                    fprintf(log_file, "%s v_mx: %f\n", time_buff, v_mx);
                    fflush(log_file);
                    update = 1;
                }
                break;
        }

        sleep(1);

        p_mx = p_mx_old + v_mx;
        if (p_mx > 39) {
            p_mx = 39;
        } else if (p_mx < 0) {
            p_mx = 0;
        }
        timestamp();
        fprintf(log_file, "%s p_mx: %f\n", time_buff, p_mx);
        fflush(log_file);

        if (update) {
            error = (double)rand() / RAND_MAX * max_error_percentage * 2 - max_error_percentage;
            p_mx_old = p_mx * (1 + error);
            update = 0;
        } else {
            p_mx_old = p_mx;
        }

        sprintf(p_mx_fifo_payload, "%f", p_mx_old);
        write_to_fifo(p_mx_fd, p_mx_fifo_payload, "Error while writing to p_mx_fifo");
        write_to_fifo(watchdog_p_mx_fd, p_mx_fifo_payload, "Error while writing to watchdog_p_mx_fifo");

        timestamp();
        fprintf(log_file, "%s p_mx with noise: %f\n", time_buff, p_mx_old);
        fflush(log_file);
    }

    close(v_mx_fd);
    close(p_mx_fd);
    close(watchdog_p_mx_fd);

    timestamp();
    fprintf(log_file, "%s log closed\n", time_buff);
    fflush(log_file);
    fclose(log_file);

    return 0;
}

