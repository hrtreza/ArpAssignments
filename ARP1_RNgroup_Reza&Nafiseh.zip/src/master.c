#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <signal.h>
#include <time.h>

#define v_mx_fifo "/tmp/v_mx_fifo"
#define v_mz_fifo "/tmp/v_mz_fifo"
#define p_mx_fifo "/tmp/p_mx_fifo"
#define p_mz_fifo "/tmp/p_mz_fifo"
#define watchdog_p_mx_fifo "/tmp/watchdog_p_mx_fifo"
#define watchdog_p_mz_fifo "/tmp/watchdog_p_mz_fifo"

FILE *log_file;

char time_buff[20];
struct tm *sTm;
time_t t;

void timestamp() {
  t = time(NULL);
  sTm = gmtime (&t);
  strftime (time_buff, sizeof(time_buff), "%Y-%m-%d %H:%M:%S", sTm);
}

int spawn(const char * program, char * arg_list[]) {

  pid_t child_pid = fork();

  if(child_pid < 0) {
    perror("Error while forking...");
    return 1;
  }

  else if(child_pid != 0) {
    return child_pid;
  }

  else {
    if(execvp (program, arg_list) == 0);
    perror("Exec failed");
    return 1;
  }
}

int main() {
  //******** log init ********//
  log_file = fopen("log/master.log", "w");
	if (log_file == NULL) {
    perror("Error while opening the log file");
    return 1;
  }

  //******** log ********//
  timestamp();
  fprintf(log_file,"%s log started\n", time_buff);
  fflush(log_file);

  //******** Create FIFOs ********//
  if(mkfifo(v_mx_fifo, 0666) == -1) {
    perror("Error while creating v_mx_fifo");
    //******** log ********//
    timestamp();
    fprintf(log_file,"%s Error while creating v_mx_fifo\n", time_buff);
    fflush(log_file);
  }
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Creation of v_mx_fifo\n", time_buff);
  fflush(log_file);

  if(mkfifo(v_mz_fifo, 0666) == -1) {
    perror("Error while creating v_mz_fifo");
    //******** log ********//
    timestamp();
    fprintf(log_file,"%s Error while creating v_mz_fifo\n", time_buff);
    fflush(log_file);
  }
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Creation of v_mz_fifo\n", time_buff);
  fflush(log_file);
  if(mkfifo(p_mx_fifo, 0666) == -1) {
    perror("Error while creating p_mx_fifo");
    //******** log ********//
    timestamp();
    fprintf(log_file,"%s Error while creating p_mx_fifo\n", time_buff);
    fflush(log_file);
  }
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Creation of p_mx_fifo\n", time_buff);
  fflush(log_file);

  if(mkfifo(p_mz_fifo, 0666) == -1) {
    perror("Error while creating p_mz_fifo");
    //******** log ********//
    timestamp();
    fprintf(log_file,"%s Error while creating p_mz_fifo\n", time_buff);
    fflush(log_file);
  }
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Creation of p_mz_fifo\n", time_buff);
  fflush(log_file);

  if(mkfifo(watchdog_p_mx_fifo, 0666) == -1) {
    perror("Error while creating watchdog_p_mx_fifo");
    //******** log ********//
    timestamp();
    fprintf(log_file,"%s Error while creating watchdog_p_mx_fifo\n", time_buff);
    fflush(log_file);
  }
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Creation of watchdog_p_mx_fifo\n", time_buff);
  fflush(log_file);

  if(mkfifo(watchdog_p_mz_fifo, 0666) == -1) {
    perror("Error while creating watchdog_p_mz_fifo");
    //******** log ********//
    timestamp();
    fprintf(log_file,"%s Error while creating watchdog_p_mz_fifo\n", time_buff);
    fflush(log_file);
  }
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Creation of watchdog_p_mz_fifo\n", time_buff);
  fflush(log_file);

  sleep(2);

  char * arg_list_command[] = { "/usr/bin/konsole", "-e", "./bin/command", NULL };
  char * arg_list_inspection[] = { "/usr/bin/konsole", "-e", "./bin/inspection", NULL };
  //watchdog opens a new terminal so that timer can be seen more easily in term of debugging
  //it can be a a process without terminal and timer will be seen in the other terminal
  char * arg_list_watchdog[] = { "/usr/bin/konsole", "-e", "./bin/watchdog", NULL };
  char * arg_list_motorx[] = { "./bin/motorx", NULL };
  char * arg_list_motorz[] = { "./bin/motorz", NULL };

  pid_t pid_cmd = spawn("/usr/bin/konsole", arg_list_command);
  pid_t pid_insp = spawn("/usr/bin/konsole", arg_list_inspection);
  pid_t pid_wtdg = spawn("/usr/bin/konsole", arg_list_watchdog);
  pid_t pid_motorx = spawn("./bin/motorx", arg_list_motorx);
  pid_t pid_motorz = spawn("./bin/motorz", arg_list_motorz);

  sleep(2);

  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Waiting untill any process dies\n", time_buff);
  fflush(log_file);

  int status;
  wait(&status);

  printf ("One process died %d\n", status);
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s One process died with status: %d\n", time_buff, status);
  fflush(log_file);

  kill(pid_wtdg, SIGINT);
  kill(pid_motorz, SIGINT);
  kill(pid_motorx, SIGINT);
  kill(pid_insp, SIGINT);
  kill(pid_cmd, SIGINT);

  printf ("Termination signal sent to processes \n");
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Termination signal sent to processes \n", time_buff);
  fflush(log_file);

  sleep(2);

  printf ("Main program exiting with status %d\n", status);
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s Main program exiting with status %d\n", time_buff, status);
  fflush(log_file);

  //******** Remove FIFOs *******//
  unlink(v_mx_fifo);
  unlink(v_mz_fifo);
  unlink(p_mx_fifo);
  unlink(p_mz_fifo);
  unlink(watchdog_p_mx_fifo);
  unlink(watchdog_p_mz_fifo);

  kill(pid_wtdg, SIGKILL);
  kill(pid_motorz, SIGKILL);
  kill(pid_motorx, SIGKILL);
  kill(pid_insp, SIGKILL);
  kill(pid_cmd, SIGKILL);
  //******** log ********//
  timestamp();
  fprintf(log_file,"%s log closed\n", time_buff);
  fflush(log_file);
  fclose(log_file);

  return 0;
}
