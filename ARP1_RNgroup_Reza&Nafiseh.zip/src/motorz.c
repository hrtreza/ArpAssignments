#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>

#define VMX_FIFO "/tmp/v_mx_fifo"                     // Define the path for VMX FIFO
#define VMZ_FIFO "/tmp/v_mz_fifo"                     // Define the path for VMZ FIFO
#define PMX_FIFO "/tmp/p_mx_fifo"                     // Define the path for PMX FIFO
#define PMZ_FIFO "/tmp/p_mz_fifo"                     // Define the path for PMZ FIFO
#define WATCHDOG_PMX_FIFO "/tmp/watchdog_p_mx_fifo"   // Define the path for watchdog PMX FIFO
#define WATCHDOG_PMZ_FIFO "/tmp/watchdog_p_mz_fifo"   // Define the path for watchdog PMZ FIFO

FILE *log_file;
char time_buff[20];
struct tm *sTm;
time_t t;

float v_mz = 0.0;     // Current velocity of MZ motor
float p_mz = 0.0;     // Current position of MZ motor
float p_mz_old = 0.0; // Previous position of MZ motor
int update = 0;       // Flag indicating if there's an update in the position
int reset = 0;        // Flag indicating if there's a reset

char v_mz_fifo_payload[100];   // Buffer for reading VMZ FIFO data
char p_mz_fifo_payload[100];   // Buffer for writing PMZ FIFO data
int v_mz_fd, p_mz_fd, watchdog_p_mz_fd; // File descriptors for FIFOs
int r_status, w_status; // Status variables for read and write operations

// Function to get the current timestamp
void timestamp() {
    t = time(NULL);
    sTm = gmtime(&t);
    strftime(time_buff, sizeof(time_buff), "%Y-%m-%d %H:%M:%S", sTm);
}

// Signal handler for STP signal
void STP_sig_handler(int signal) {
    v_mz = 0.0;
    reset = 0;
    timestamp();
    fprintf(log_file, "%s Emergency Motorx Stopped\n", time_buff);
    fprintf(log_file, "%s v_mz = %f\n", time_buff, v_mz);
    fflush(log_file);
}

// Signal handler for RST signal
void RST_sig_handler(int signal) {
    v_mz = -1.0;
    reset = 1;
}

// Signal handler for Terminate signal
void Terminate(int signal) {
    timestamp();
    fprintf(log_file, "%s Terminating\n", time_buff);
    fflush(log_file);

    close(v_mz_fd);
    close(p_mz_fd);
    close(watchdog_p_mz_fd);

    timestamp();
    fprintf(log_file, "%s log closed\n", time_buff);
    fflush(log_file);

    fclose(log_file);

    exit(EXIT_SUCCESS);
}

// General signal handler
void sig_handler(int signal) {
    switch (signal) {
        case SIGUSR1:
            STP_sig_handler(signal);
            break;
        case SIGUSR2:
            RST_sig_handler(signal);
            break;
        case SIGINT:
            Terminate(signal);
            break;
        case SIGTERM:
            Terminate(signal);
            break;
        default:
            break;
    }
}

int main(int argc, char *argv[]) {
    log_file = fopen("log/motorz.log", "w");    // Open the log file
    if (log_file == NULL) {
        perror("Error while opening the log file");
        return 1;
    }

    timestamp();
    fprintf(log_file, "%s log started\n", time_buff);
    fflush(log_file);

    v_mz_fd = open(VMZ_FIFO, O_RDONLY | O_NONBLOCK);    // Open VMZ FIFO in read-only non-blocking mode
    if (v_mz_fd == -1) {
        perror("Error while opening v_mz_fifo");
        timestamp();
        fprintf(log_file, "%s Error while opening v_mz_fifo\n", time_buff);
        fflush(log_file);
    }

    p_mz_fd = open(PMZ_FIFO, O_WRONLY);    // Open PMZ FIFO in write-only mode
    if (p_mz_fd == -1) {
        perror("Error while opening p_mz_fifo");
        timestamp();
        fprintf(log_file, "%s Error while opening p_mz_fifo\n", time_buff);
        fflush(log_file);
    }

    watchdog_p_mz_fd = open(WATCHDOG_PMZ_FIFO, O_WRONLY);    // Open watchdog PMZ FIFO in write-only mode
    if (watchdog_p_mz_fd == -1) {
        perror("Error while opening watchdog_p_mz_fifo");
        timestamp();
        fprintf(log_file, "%s Error while opening watchdog_p_mz_fifo\n", time_buff);
        fflush(log_file);
    }

    srand(time(NULL));
    double max_error_percentage = 0.05;
    double error = 0.0;

    // Register signal handlers
    if (signal(SIGUSR1, sig_handler) == SIG_ERR) {
        perror("Error while getting STP signal");
        timestamp();
        fprintf(log_file, "%s Error while getting STP signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGUSR2, sig_handler) == SIG_ERR) {
        perror("Error while getting RST signal");
        timestamp();
        fprintf(log_file, "%s Error while getting RST signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGINT, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        timestamp();
        fprintf(log_file, "%s Error while getting Terminate signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGTERM, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        timestamp();
        fprintf(log_file, "%s Error while getting Terminate signal\n", time_buff);
        fflush(log_file);
    }

    while (1) {
        switch (reset) {
            case 1:
                if (p_mz_old == 0) {
                    v_mz = 0.0;
                    reset = 0;
                } else {
                    v_mz = -1.0;
                    update = 1;
                }
                timestamp();
                fprintf(log_file, "%s v_mz in reset mode: %f\n", time_buff, v_mz);
                fflush(log_file);
                break;
            default:
                r_status = read(v_mz_fd, v_mz_fifo_payload, 100);    // Read from VMZ FIFO
                if (r_status > 0) {
                    v_mz = atof(v_mz_fifo_payload);    // Convert read data to float
                    timestamp();
                    fprintf(log_file, "%s v_mz: %f\n", time_buff, v_mz);
                    fflush(log_file);

                    update = 1;
                }
                break;
        }

        sleep(1);   // Pause for 1 second

        p_mz = p_mz_old + v_mz;   // Calculate new position

        timestamp();
        fprintf(log_file, "%s p_mz: %f\n", time_buff, p_mz);
        fflush(log_file);

        if (update) {
            error = (double)rand() / RAND_MAX * max_error_percentage * 2 - max_error_percentage;   // Generate random error
            p_mz_old = p_mz * (1 + error);    // Apply error to the position
            if (p_mz_old > 9) {
                p_mz_old = 9;
                v_mz = 0.0;
            } else if (p_mz_old < 0) {
                p_mz_old = 0;
                v_mz = 0.0;
            }
            update = 0;
        } else {
            p_mz_old = p_mz;
            if (p_mz_old > 9) {
                p_mz_old = 9;
                v_mz = 0.0;
            } else if (p_mz_old < 0) {
                p_mz_old = 0;
                v_mz = 0.0;
            }
        }

        sprintf(p_mz_fifo_payload, "%f", p_mz_old);    // Convert p_mz_old to string
        w_status = write(p_mz_fd, p_mz_fifo_payload, strlen(p_mz_fifo_payload));    // Write p_mz_old to PMZ FIFO
        if (w_status == -1) {
            perror("Error while writing to p_mz_fifo");
            timestamp();
            fprintf(log_file, "%s Error while writing to p_mz_fifo\n", time_buff);
            fflush(log_file);
        }
        w_status = write(watchdog_p_mz_fd, p_mz_fifo_payload, strlen(p_mz_fifo_payload));    // Write p_mz_old to watchdog PMZ FIFO
        if (w_status == -1) {
            perror("Error while writing to watchdog_p_mz_fifo");
            timestamp();
            fprintf(log_file, "%s Error while writing to watchdog_p_mz_fifo\n", time_buff);
            fflush(log_file);
        }

        timestamp();
        fprintf(log_file, "%s p_mz with noise: %f\n", time_buff, p_mz_old);
        fflush(log_file);
    }

    close(v_mz_fd);   // Close VMZ FIFO
    close(p_mz_fd);   // Close PMZ FIFO

    timestamp();
    fprintf(log_file, "%s log closed\n", time_buff);
    fflush(log_file);
    fclose(log_file);

    return 0;
}

