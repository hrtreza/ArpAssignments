#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <signal.h>
#include <time.h>

#define V_MX_FIFO "/tmp/v_mx_fifo"
#define V_MZ_FIFO "/tmp/v_mz_fifo"
#define P_MX_FIFO "/tmp/p_mx_fifo"
#define P_MZ_FIFO "/tmp/p_mz_fifo"
#define WATCHDOG_P_MX_FIFO "/tmp/watchdog_p_mx_fifo"
#define WATCHDOG_P_MZ_FIFO "/tmp/watchdog_p_mz_fifo"

#define WATCHDOG_TIMEOUT 60

FILE *log_file;
char time_buff[20];
struct tm *sTm;
time_t t;

float p_mx = 0.0;
float p_mz = 0.0;
float p_mx_old = 0.0;
float p_mz_old = 0.0;
int counter = WATCHDOG_TIMEOUT;
char p_mx_wtdg_fifo_payload[100];
char p_mz_wtdg_fifo_payload[100];
int p_mx_wtdg_fd, p_mz_wtdg_fd, maxfd;
int r_status, w_status;

// Function to get the current timestamp
void timestamp() {
    t = time(NULL);
    sTm = gmtime(&t);
    strftime(time_buff, sizeof(time_buff), "%Y-%m-%d %H:%M:%S", sTm);
}

// Function to handle termination signals (SIGINT and SIGTERM)
void Terminate(int signal) {
    printf("Terminating\n");
    // Log termination
    timestamp();
    fprintf(log_file, "%s Terminating\n", time_buff);
    fflush(log_file);
    // Close FIFOs
    close(p_mx_wtdg_fd);
    close(p_mz_wtdg_fd);
    fclose(log_file);
    // Terminate
    exit(EXIT_SUCCESS);
}

// Signal handler function
void sig_handler(int signal) {
    switch (signal) {
        case SIGINT:
        case SIGTERM:
            Terminate(signal);
            break;
    }
}

// Function to get the PID of a process by its name
int get_pid(const char *process_name) {
    char line[10];
    FILE *pid_file = popen((char *) malloc(strlen(process_name) + 15), "r");
    fgets(line, sizeof(line), pid_file);
    long pid = strtol(line, NULL, 10);
    pclose(pid_file);
    return (int) pid;
}

int main() {
    // Get PID of processes to send signals
    int sig_status;
    long pid_cmd = get_pid("command");
    long pid_insp = get_pid("insp");
    long pid_motorx = get_pid("motorx");
    long pid_motorz = get_pid("motorz");

    // Initialize log file
    log_file = fopen("log/watchdog.log", "w");
    if (log_file == NULL) {
        perror("Error opening the log file");
        return 1;
    }
    // Log start
    timestamp();
    fprintf(log_file, "%s log started\n", time_buff);
    fflush(log_file);

    // Initialize FIFOs
    fd_set readfds;
    // Open watchdog_p_mx_fifo
    p_mx_wtdg_fd = open(WATCHDOG_P_MX_FIFO, O_RDONLY | O_NONBLOCK);
    if (p_mx_wtdg_fd == -1) {
        perror("Error opening watchdog_p_mx_fifo");
        // Log error
        timestamp();
        fprintf(log_file, "%s Error opening watchdog_p_mx_fifo\n", time_buff);
        fflush(log_file);
    }
    // Open watchdog_p_mz_fifo
    p_mz_wtdg_fd = open(WATCHDOG_P_MZ_FIFO, O_RDONLY | O_NONBLOCK);
    if (p_mz_wtdg_fd == -1) {
        perror("Error opening watchdog_p_mz_fifo");
        timestamp();
        fprintf(log_file, "%s Error while opening watchdog_p_mz_fifo\n", time_buff);
        fflush(log_file);
    }

    // Register signal handlers
    if (signal(SIGINT, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        timestamp();
        fprintf(log_file, "%s Error getting Terminate signal\n", time_buff);
        fflush(log_file);
    }
    if (signal(SIGTERM, sig_handler) == SIG_ERR) {
        perror("Error while getting Terminate signal");
        timestamp();
        fprintf(log_file, "%s Error getting Terminate signal\n", time_buff);
        fflush(log_file);
    }

    maxfd = (p_mx_wtdg_fd > p_mz_wtdg_fd) ? p_mx_wtdg_fd : p_mz_wtdg_fd;

    while (1) {
        FD_ZERO(&readfds);

        FD_SET(p_mx_wtdg_fd, &readfds);
        FD_SET(p_mz_wtdg_fd, &readfds);

        // Wait for data on p_mx_fifo or p_mz_fifo
        select(maxfd + 1, &readfds, NULL, NULL, NULL);

        // If data is available on p_mx_fifo
        if (FD_ISSET(p_mx_wtdg_fd, &readfds)) {
            r_status = read(p_mx_wtdg_fd, p_mx_wtdg_fifo_payload, 100);
            if (r_status > 0) {
                p_mx = atof(p_mx_wtdg_fifo_payload);
            }
        }
        // If data is available on p_mz_fifo
        if (FD_ISSET(p_mz_wtdg_fd, &readfds)) {
            r_status = read(p_mz_wtdg_fd, p_mz_wtdg_fifo_payload, 100);
            if (r_status > 0) {
                p_mz = atof(p_mz_wtdg_fifo_payload);
            }
        }

        if (p_mx != p_mx_old || p_mz != p_mz_old) {
            counter = WATCHDOG_TIMEOUT;
        } else if (p_mx == p_mx_old && p_mz == p_mz_old) {
            counter--;
            // Log counter, p_mx, and p_mz values
            timestamp();
            fprintf(log_file, "%s counter: %d\n", time_buff, counter);
            fflush(log_file);
            timestamp();
            fprintf(log_file, "%s p_mx: %f\n", time_buff, p_mx);
            fflush(log_file);
            timestamp();
            fprintf(log_file, "%s p_mz: %f\n", time_buff, p_mz);
            fflush(log_file);
        }

        if (counter == 0) {
            // Log watchdog timeout
            timestamp();
            fprintf(log_file, "%s watchdog timeout\n", time_buff);
            fprintf(log_file, "%s sending termination signal to processes\n", time_buff);
            fprintf(log_file, "%s log closed\n", time_buff);
            fflush(log_file);
            fclose(log_file);

            // Send termination signals to processes
            kill(pid_motorx, SIGINT);
            kill(pid_motorz, SIGINT);
            kill(pid_insp, SIGINT);
            kill(pid_cmd, SIGINT);
            // Terminate
            exit(EXIT_SUCCESS);
        }

        printf("*******************counter: %d\n", counter);
        printf("p_mx: %f\n", p_mx);
        printf("p_mx_old: %f\n", p_mx_old);
        printf("p_mz: %f\n", p_mz);
        printf("p_mz_old: %f\n", p_mz_old);

        p_mx_old = p_mx;
        p_mz_old = p_mz;

        sleep(1);
    }

    timestamp();
    fprintf(log_file, "%s log closed\n", time_buff);
    fflush(log_file);
    fclose(log_file);

    // Terminate
    exit(EXIT_SUCCESS);
    return 0;
}

